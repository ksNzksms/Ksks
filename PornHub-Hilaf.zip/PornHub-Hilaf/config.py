import os

TOKEN = os.environ.get("TOKEN", "")
ARQ_API_KEY = os.environ.get("ARQ_API_KEY", "")
REPO_BOT = os.environ.get("REPO_BOT", "https://t.me/spacecloud")
OWNER = os.environ.get("OWNER", "")
BOT_NAME = os.environ.get("BOT_NAME", "")
UPDATES_CHANNEL = os.environ.get("UPDATES_CHANNEL", "spacecloud")
